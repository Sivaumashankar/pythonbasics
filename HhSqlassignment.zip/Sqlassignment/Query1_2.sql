CREATE TABLE EmployeeDetails(emp_id int primary key, 
emp_name varchar(20) not null,
job_name varchar(20) not null,
manager_id int not null ,
 hire_date date not null,
salary int not null,
Dep_id int not null);
